import React, { useState, useEffect } from 'react';
import { PageId, Testimonial, PendingReview, AreaRequest, TutorApplication } from './types';
import { TUTORIA_CONFIG, DEFAULT_TESTIMONIALS } from './data';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { WhatsAppFloat } from './components/WhatsAppFloat';
import { TermsModal } from './components/TermsModal';
import { AdminModal } from './components/AdminModal';
import { AreaRequestModal } from './components/AreaRequestModal';
import { HomePage } from './pages/HomePage';
import { JoinTutorPage } from './pages/JoinTutorPage';
import { ApplyPage } from './pages/ApplyPage';
import { ContactPage } from './pages/ContactPage';
import { ReviewPage } from './pages/ReviewPage';

const TESTIMONIALS_STORAGE_KEY = 'tutoria:testimonials';
const PENDING_STORAGE_KEY = 'tutoria:pending';
const AREA_REQUESTS_STORAGE_KEY = 'tutoria:area_requests';
const TUTOR_APPLICATIONS_STORAGE_KEY = 'tutoria:tutor_applications';

export default function App() {
  const [currentPage, setCurrentPage] = useState<PageId>('home');
  const [isTermsOpen, setIsTermsOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isAreaRequestOpen, setIsAreaRequestOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Testimonials & Pending Reviews State with local persistence
  const [testimonials, setTestimonials] = useState<Testimonial[]>(() => {
    try {
      const saved = localStorage.getItem(TESTIMONIALS_STORAGE_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // ignore
    }
    return DEFAULT_TESTIMONIALS;
  });

  const [pendingReviews, setPendingReviews] = useState<PendingReview[]>(() => {
    try {
      const saved = localStorage.getItem(PENDING_STORAGE_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // ignore
    }
    return [];
  });

  // Area / Tutor Requests State with local persistence
  const [areaRequests, setAreaRequests] = useState<AreaRequest[]>(() => {
    try {
      const saved = localStorage.getItem(AREA_REQUESTS_STORAGE_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // ignore
    }
    return [];
  });

  // Tutor Applications State with local persistence
  const [tutorApplications, setTutorApplications] = useState<TutorApplication[]>(() => {
    try {
      const saved = localStorage.getItem(TUTOR_APPLICATIONS_STORAGE_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // ignore
    }
    return [];
  });

  // Save to localStorage when updated
  useEffect(() => {
    try {
      localStorage.setItem(TESTIMONIALS_STORAGE_KEY, JSON.stringify(testimonials));
    } catch {
      // ignore
    }
  }, [testimonials]);

  useEffect(() => {
    try {
      localStorage.setItem(PENDING_STORAGE_KEY, JSON.stringify(pendingReviews));
    } catch {
      // ignore
    }
  }, [pendingReviews]);

  useEffect(() => {
    try {
      localStorage.setItem(AREA_REQUESTS_STORAGE_KEY, JSON.stringify(areaRequests));
    } catch {
      // ignore
    }
  }, [areaRequests]);

  useEffect(() => {
    try {
      localStorage.setItem(TUTOR_APPLICATIONS_STORAGE_KEY, JSON.stringify(tutorApplications));
    } catch {
      // ignore
    }
  }, [tutorApplications]);

  // Handle URL hash navigation on mount and changes
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.replace('#', '');
      if (hash === 'join-as-tutor' || hash === 'apply' || hash === 'contact' || hash === 'review') {
        setCurrentPage(hash as PageId);
      } else if (hash.startsWith('boards')) {
        setCurrentPage('home');
        setTimeout(() => {
          document.getElementById('boards')?.scrollIntoView({ behavior: 'smooth' });
        }, 100);
      } else {
        setCurrentPage('home');
      }
    };

    handleHashChange();
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const navigateTo = (page: PageId, hash?: string) => {
    setCurrentPage(page);
    if (hash) {
      window.location.hash = hash;
      setTimeout(() => {
        const el = document.getElementById(hash);
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      }, 50);
    } else {
      window.location.hash = page === 'home' ? '' : page;
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  };

  const buildWhatsAppUrl = (message?: string) => {
    const msg = encodeURIComponent(message || TUTORIA_CONFIG.whatsappDefaultMessage);
    return `https://wa.me/${TUTORIA_CONFIG.whatsappNumber}?text=${msg}`;
  };

  // Testimonial actions
  const handleAddTestimonial = (testimonial: Testimonial) => {
    setTestimonials((prev) => [testimonial, ...prev]);
    showToast('New testimonial published successfully.');
  };

  const handleRemoveTestimonial = (index: number) => {
    setTestimonials((prev) => {
      const next = [...prev];
      next.splice(index, 1);
      return next;
    });
    showToast('Testimonial removed.');
  };

  const handleSubmitReview = (review: PendingReview) => {
    setPendingReviews((prev) => [review, ...prev]);
    showToast('Review submitted! It will appear after admin review.');
  };

  const handleApprovePending = (index: number) => {
    const item = pendingReviews[index];
    if (!item) return;

    // Remove from pending
    setPendingReviews((prev) => {
      const next = [...prev];
      next.splice(index, 1);
      return next;
    });

    // Add to live testimonials
    setTestimonials((prev) => [
      {
        id: item.id || Date.now().toString(),
        name: item.name,
        meta: item.meta,
        quote: item.quote,
        rating: item.rating || '5 / 5',
      },
      ...prev,
    ]);

    showToast(`Approved "${item.name}" review! It is now live on the site.`);
  };

  const handleRejectPending = (index: number) => {
    setPendingReviews((prev) => {
      const next = [...prev];
      next.splice(index, 1);
      return next;
    });
    showToast('Pending review rejected.');
  };

  // Area / Tutor Request actions
  const handleSubmitAreaRequest = (request: AreaRequest) => {
    setAreaRequests((prev) => [request, ...prev]);
    showToast(`Request submitted for ${request.area}! Our team will contact you shortly.`);
  };

  const handleRemoveAreaRequest = (id: string) => {
    setAreaRequests((prev) => prev.filter((r) => r.id !== id));
    showToast('Area request deleted.');
  };

  const handleToggleAreaRequestStatus = (id: string) => {
    setAreaRequests((prev) =>
      prev.map((r) => {
        if (r.id === id) {
          const nextStatus: AreaRequest['status'] =
            r.status === 'Pending' ? 'Contacted' : r.status === 'Contacted' ? 'Assigned' : 'Pending';
          return { ...r, status: nextStatus };
        }
        return r;
      })
    );
  };

  // Tutor Application actions
  const handleSubmitTutorApplication = (application: TutorApplication) => {
    setTutorApplications((prev) => [application, ...prev]);
    showToast(`Application received for ${application.name}! Our team will contact you.`);
  };

  const handleRemoveTutorApplication = (id: string) => {
    setTutorApplications((prev) => prev.filter((app) => app.id !== id));
    showToast('Tutor application deleted.');
  };

  const handleToggleTutorApplicationStatus = (id: string) => {
    setTutorApplications((prev) =>
      prev.map((app) => {
        if (app.id === id) {
          const nextStatus: TutorApplication['status'] =
            app.status === 'Pending' ? 'Contacted' : app.status === 'Contacted' ? 'Verified' : 'Pending';
          return { ...app, status: nextStatus };
        }
        return app;
      })
    );
  };

  return (
    <div className="tutoria-app min-h-screen flex flex-col justify-between">
      {/* Toast notification */}
      {toastMessage && (
        <div
          style={{
            position: 'fixed',
            top: '20px',
            right: '20px',
            zIndex: 9999,
            background: '#0F172A',
            color: '#FFFFFF',
            padding: '12px 20px',
            borderRadius: '10px',
            boxShadow: '0 10px 25px rgba(0,0,0,0.3)',
            fontSize: '0.9rem',
            fontWeight: 600,
            borderLeft: '4px solid #25D366',
          }}
        >
          {toastMessage}
        </div>
      )}

      {/* Main Header */}
      <Header
        currentPage={currentPage}
        onNavigate={navigateTo}
        buildWhatsAppUrl={buildWhatsAppUrl}
      />

      {/* Page Content */}
      <main className="flex-1">
        {currentPage === 'home' && (
          <HomePage
            onNavigate={navigateTo}
            buildWhatsAppUrl={buildWhatsAppUrl}
            testimonials={testimonials}
            onOpenAreaRequest={() => setIsAreaRequestOpen(true)}
          />
        )}

        {currentPage === 'join-as-tutor' && <JoinTutorPage onNavigate={navigateTo} />}

        {currentPage === 'apply' && (
          <ApplyPage
            onOpenTerms={() => setIsTermsOpen(true)}
            onNavigate={navigateTo}
            onSubmitApplication={handleSubmitTutorApplication}
          />
        )}

        {currentPage === 'contact' && <ContactPage buildWhatsAppUrl={buildWhatsAppUrl} />}

        {currentPage === 'review' && (
          <ReviewPage onSubmitReview={handleSubmitReview} onNavigate={navigateTo} />
        )}
      </main>

      {/* Main Footer */}
      <Footer onNavigate={navigateTo} buildWhatsAppUrl={buildWhatsAppUrl} />

      {/* Floating WhatsApp Action Button */}
      <WhatsAppFloat buildWhatsAppUrl={buildWhatsAppUrl} />

      {/* Admin FAB & Modal */}
      <button
        type="button"
        className="admin-fab"
        id="adminFab"
        onClick={() => setIsAdminOpen(true)}
      >
        Admin
      </button>

      <AdminModal
        isOpen={isAdminOpen}
        onClose={() => setIsAdminOpen(false)}
        testimonials={testimonials}
        pendingReviews={pendingReviews}
        areaRequests={areaRequests}
        tutorApplications={tutorApplications}
        onAddTestimonial={handleAddTestimonial}
        onRemoveTestimonial={handleRemoveTestimonial}
        onApprovePending={handleApprovePending}
        onRejectPending={handleRejectPending}
        onRemoveAreaRequest={handleRemoveAreaRequest}
        onToggleAreaRequestStatus={handleToggleAreaRequestStatus}
        onRemoveTutorApplication={handleRemoveTutorApplication}
        onToggleTutorApplicationStatus={handleToggleTutorApplicationStatus}
      />

      {/* Terms & Conditions Modal */}
      <TermsModal isOpen={isTermsOpen} onClose={() => setIsTermsOpen(false)} />

      {/* Area & Tutor Application Request Modal */}
      <AreaRequestModal
        isOpen={isAreaRequestOpen}
        onClose={() => setIsAreaRequestOpen(false)}
        onSubmitRequest={handleSubmitAreaRequest}
      />
    </div>
  );
}

import React, { useState } from 'react';
import { AreaRequest } from '../types';

interface AreaRequestModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmitRequest: (request: AreaRequest) => void;
}

const CLASS_OR_EXAM_OPTIONS = [
  'Class 1 – 5 (Primary Foundation)',
  'Class 6 – 8 (Middle School)',
  'Class 9 & 10 (Madhyamik / ICSE / CBSE)',
  'Class 11 & 12 (WBCHSE / ISC / CBSE)',
  'NEET (Medical Entrance)',
  'JEE Main & Advanced (Engineering)',
  'WBJEE Exam Preparation',
  'WBCS / Government Exam Foundation',
  'Olympiads & NTSE',
  'Spoken English & Communication',
  'Other Special Exam / Course',
];

const TUTORING_TYPES = [
  'Home Tutor (In-Person / Offline)',
  'Online 1-on-1 Live Tutoring',
  'Crash Course / Fast-Track Revision',
  'Special Exam Coaching',
  'Both Offline & Online Hybrid',
];

const POPULAR_AREAS = [
  'Bardhaman',
  'Kharagpur',
  'Malda',
  'Midnapore',
  'Berhampore',
  'Hooghly',
  'Serampore',
  'Barasat',
  'Kalyani',
  'Haldia',
  'Krishnanagar',
  'Barrackpore',
  'Jalpaiguri',
  'Bankura',
  'Purulia',
  'Bolpur / Santiniketan',
  'Cooch Behar',
  'Raiganj',
];

export const AreaRequestModal: React.FC<AreaRequestModalProps> = ({
  isOpen,
  onClose,
  onSubmitRequest,
}) => {
  const [area, setArea] = useState('');
  const [phone, setPhone] = useState('');
  const [name, setName] = useState('');
  const [classOrExam, setClassOrExam] = useState(CLASS_OR_EXAM_OPTIONS[0]);
  const [customExam, setCustomExam] = useState('');
  const [tutoringType, setTutoringType] = useState(TUTORING_TYPES[0]);
  const [notes, setNotes] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [submittedData, setSubmittedData] = useState<AreaRequest | null>(null);
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const handleAreaPillClick = (selectedArea: string) => {
    setArea(selectedArea);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    const cleanArea = area.trim();
    const cleanPhone = phone.trim();

    if (!cleanArea) {
      setErrorMsg('Please enter your requested area / locality.');
      return;
    }

    // Phone validation (at least 10 digits)
    const digitsOnly = cleanPhone.replace(/\D/g, '');
    if (digitsOnly.length < 10) {
      setErrorMsg('Please enter a valid 10-digit phone number so we can reach you.');
      return;
    }

    const finalClassOrExam =
      classOrExam === 'Other Special Exam / Course' && customExam.trim()
        ? customExam.trim()
        : classOrExam;

    const newRequest: AreaRequest = {
      id: 'REQ-' + Math.floor(100000 + Math.random() * 900000),
      name: name.trim() || 'Parent / Student',
      phone: cleanPhone,
      area: cleanArea,
      classOrExam: finalClassOrExam,
      tutoringType,
      notes: notes.trim() || undefined,
      submittedAt: new Date().toLocaleString('en-IN', {
        dateStyle: 'medium',
        timeStyle: 'short',
      }),
      status: 'Pending',
    };

    onSubmitRequest(newRequest);
    setSubmittedData(newRequest);
    setIsSubmitted(true);
  };

  const handleResetAndNew = () => {
    setArea('');
    setPhone('');
    setName('');
    setClassOrExam(CLASS_OR_EXAM_OPTIONS[0]);
    setCustomExam('');
    setTutoringType(TUTORING_TYPES[0]);
    setNotes('');
    setIsSubmitted(false);
    setSubmittedData(null);
    setErrorMsg('');
  };

  const handleClose = () => {
    handleResetAndNew();
    onClose();
  };

  return (
    <div
      className="area-modal-overlay open"
      id="areaRequestOverlay"
      onClick={(e) => {
        if (e.target === e.currentTarget) handleClose();
      }}
      role="dialog"
      aria-modal="true"
      aria-labelledby="areaRequestTitle"
    >
      <div className="area-modal-card">
        <button
          type="button"
          className="area-modal-close"
          onClick={handleClose}
          aria-label="Close modal"
        >
          &times;
        </button>

        {!isSubmitted ? (
          <div>
            <div className="area-modal-header">
              <span className="area-modal-badge">
                <svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor" aria-hidden="true">
                  <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" />
                </svg>
                Custom Area Request
              </span>
              <h2 className="area-modal-title" id="areaRequestTitle">
                Request a Tutor for Your Area<span>.</span>
              </h2>
              <p className="area-modal-subtitle">
                Don't see your specific location listed? Submit your area and learning requirement below.
                Our team will match you with verified home tutors.
              </p>
            </div>

            {errorMsg && (
              <div className="area-modal-error" role="alert">
                <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="12" cy="12" r="10" />
                  <line x1="12" y1="8" x2="12" y2="12" />
                  <line x1="12" y1="16" x2="12.01" y2="16" />
                </svg>
                <span>{errorMsg}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="area-modal-form">
              {/* Area Field */}
              <div className="area-form-group">
                <label htmlFor="reqArea">
                  Area / Locality / Landmark <span className="req-star">*</span>
                </label>
                <div className="input-with-icon">
                  <svg className="field-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" />
                    <circle cx="12" cy="10" r="3" />
                  </svg>
                  <input
                    id="reqArea"
                    type="text"
                    required
                    placeholder="e.g. Burdwan Town, Medinipur, Barasat, or your locality"
                    value={area}
                    onChange={(e) => setArea(e.target.value)}
                    className="area-input"
                  />
                </div>

                {/* Popular suggestions */}
                <div className="area-suggestions-label">Quick select:</div>
                <div className="area-quick-pills">
                  {POPULAR_AREAS.map((pArea) => (
                    <button
                      type="button"
                      key={pArea}
                      className={`area-quick-pill ${area === pArea ? 'active' : ''}`}
                      onClick={() => handleAreaPillClick(pArea)}
                    >
                      {pArea}
                    </button>
                  ))}
                </div>
              </div>

              <div className="area-form-row">
                {/* Phone Number Field */}
                <div className="area-form-group">
                  <label htmlFor="reqPhone">
                    Phone Number (Ph Number) <span className="req-star">*</span>
                  </label>
                  <div className="input-with-icon">
                    <svg className="field-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" />
                    </svg>
                    <input
                      id="reqPhone"
                      type="tel"
                      required
                      placeholder="+91 98765 43210"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="area-input"
                    />
                  </div>
                  <span className="field-hint">We will call or SMS you on this number.</span>
                </div>

                {/* Name Field */}
                <div className="area-form-group">
                  <label htmlFor="reqName">Student / Parent Name (Optional)</label>
                  <div className="input-with-icon">
                    <svg className="field-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
                      <circle cx="12" cy="7" r="4" />
                    </svg>
                    <input
                      id="reqName"
                      type="text"
                      placeholder="e.g. Suman Sen"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="area-input"
                    />
                  </div>
                </div>
              </div>

              {/* Class or Special Exam Field */}
              <div className="area-form-group">
                <label htmlFor="reqClassOrExam">
                  Class or Special Exam <span className="req-star">*</span>
                </label>
                <div className="input-with-icon">
                  <svg className="field-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" />
                    <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z" />
                  </svg>
                  <select
                    id="reqClassOrExam"
                    value={classOrExam}
                    onChange={(e) => setClassOrExam(e.target.value)}
                    className="area-select"
                    required
                  >
                    {CLASS_OR_EXAM_OPTIONS.map((opt) => (
                      <option key={opt} value={opt}>
                        {opt}
                      </option>
                    ))}
                  </select>
                </div>

                {classOrExam === 'Other Special Exam / Course' && (
                  <div className="mt-2">
                    <input
                      type="text"
                      placeholder="Enter specific exam (e.g. CAT, CLAT, CUET, NDA, etc.)"
                      value={customExam}
                      onChange={(e) => setCustomExam(e.target.value)}
                      className="area-input"
                      required
                    />
                  </div>
                )}
              </div>

              {/* Type Field */}
              <div className="area-form-group">
                <label htmlFor="reqType">
                  Tutoring Type / Mode <span className="req-star">*</span>
                </label>
                <div className="input-with-icon">
                  <svg className="field-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <rect x="2" y="7" width="20" height="14" rx="2" ry="2" />
                    <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16" />
                  </svg>
                  <select
                    id="reqType"
                    value={tutoringType}
                    onChange={(e) => setTutoringType(e.target.value)}
                    className="area-select"
                    required
                  >
                    {TUTORING_TYPES.map((type) => (
                      <option key={type} value={type}>
                        {type}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Specific Requirements / Subjects */}
              <div className="area-form-group">
                <label htmlFor="reqNotes">Subject Requirements / Preferred Timings (Optional)</label>
                <textarea
                  id="reqNotes"
                  rows={2}
                  placeholder="e.g. Physics & Chemistry, 3 days/week evening slots."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="area-textarea"
                />
              </div>

              <div className="area-modal-actions">
                <button type="button" className="area-modal-btn-cancel" onClick={handleClose} id="areaModalCancelBtn">
                  Cancel
                </button>
                <button type="submit" className="area-modal-btn-submit" id="areaModalSubmitBtn">
                  <span>Submit Tutor Request</span>
                  <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2.5">
                    <path d="M5 12h14M12 5l7 7-7 7" />
                  </svg>
                </button>
              </div>
            </form>
          </div>
        ) : (
          /* Confirmation / Success Screen (No WhatsApp redirect!) */
          <div className="area-success-view">
            <div className="area-success-icon-wrap">
              <div className="area-success-glow"></div>
              <svg className="area-success-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" strokeLinecap="round" strokeLinejoin="round" />
                <path d="M22 4L12 14.01l-3-3" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </div>

            <span className="area-success-badge">Application Received</span>
            <h2 className="area-success-title">
              Request Submitted Successfully<span>!</span>
            </h2>
            <p className="area-success-lead">
              Thank you! Your tutor requirement for <strong>{submittedData?.area}</strong> has been directly registered
              in our academic network.
            </p>

            {/* Summary Details Card */}
            <div className="area-success-details">
              <div className="detail-row">
                <span className="detail-label">Reference ID:</span>
                <span className="detail-val font-mono text-amber-400 font-semibold">{submittedData?.id}</span>
              </div>
              <div className="detail-row">
                <span className="detail-label">Area / Location:</span>
                <span className="detail-val">{submittedData?.area}</span>
              </div>
              <div className="detail-row">
                <span className="detail-label">Phone Number:</span>
                <span className="detail-val text-white font-medium">{submittedData?.phone}</span>
              </div>
              <div className="detail-row">
                <span className="detail-label">Class / Special Exam:</span>
                <span className="detail-val">{submittedData?.classOrExam}</span>
              </div>
              <div className="detail-row">
                <span className="detail-label">Tutoring Type:</span>
                <span className="detail-val">{submittedData?.tutoringType}</span>
              </div>
              {submittedData?.notes && (
                <div className="detail-row">
                  <span className="detail-label">Subjects / Notes:</span>
                  <span className="detail-val">{submittedData?.notes}</span>
                </div>
              )}
            </div>

            <div className="area-success-notice">
              <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="#F59E0B" strokeWidth="2">
                <circle cx="12" cy="12" r="10" />
                <polyline points="12 6 12 12 16 14" />
              </svg>
              <span>
                Our academic matching team will call you at <strong>{submittedData?.phone}</strong> within 2–4 hours
                with verified tutor profiles.
              </span>
            </div>

            <div className="area-success-actions">
              <button type="button" className="area-modal-btn-submit w-full justify-center" onClick={handleClose} id="areaModalDoneBtn">
                Done
              </button>
              <button type="button" className="area-modal-btn-cancel w-full justify-center mt-2" onClick={handleResetAndNew} id="areaModalNewReqBtn">
                Submit Another Request
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

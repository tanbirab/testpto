import React from 'react';
import { PageId } from '../types';
import { TUTORIA_CONFIG } from '../data';

interface FooterProps {
  onNavigate: (page: PageId, hash?: string) => void;
  buildWhatsAppUrl: (message?: string) => string;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate, buildWhatsAppUrl }) => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="site-footer" id="siteFooter">
      <div className="container">
        <div className="footer-top">
          <div className="footer-brand">
            <div
              className="cursor-pointer inline-block"
              onClick={() => onNavigate('home')}
              role="button"
              tabIndex={0}
            >
              <img src="/logo.svg" alt="Tutoria" />
            </div>
            <p>Verified home tutors for KG to Class 12 across West Bengal — CBSE, ICSE, WB Board and more.</p>
          </div>

          <div className="footer-col">
            <h4>Site</h4>
            <button type="button" onClick={() => onNavigate('home')}>Home</button>
            <button type="button" onClick={() => onNavigate('join-as-tutor')}>Join as Tutor</button>
            <button type="button" onClick={() => onNavigate('contact')}>Contact</button>
            <button type="button" onClick={() => onNavigate('review')}>Leave a Review</button>
            <a
              href="/tutoria-source.zip"
              download="tutoria-source.zip"
              style={{
                color: 'var(--amber-400)',
                fontWeight: 600,
                display: 'inline-flex',
                alignItems: 'center',
                gap: '6px',
              }}
            >
              <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3" />
              </svg>
              Download ZIP
            </a>
          </div>

          <div className="footer-col">
            <h4>Boards</h4>
            <button type="button" onClick={() => onNavigate('home', 'boards')}>CBSE</button>
            <button type="button" onClick={() => onNavigate('home', 'boards')}>ICSE</button>
            <button type="button" onClick={() => onNavigate('home', 'boards')}>WB Board</button>
          </div>

          <div className="footer-col">
            <h4>Contact</h4>
            <a
              href={buildWhatsAppUrl('Hi Tutoria, I have a question.')}
              target="_blank"
              rel="noopener noreferrer"
              id="footerWhatsAppBtn"
            >
              WhatsApp Us
            </a>
            <p>{TUTORIA_CONFIG.email}</p>
            <p>West Bengal, India</p>
          </div>
        </div>

        <div className="footer-bottom">
          <span>© {currentYear} Tutoria. All rights reserved.</span>
          <span>A West Bengal home tutoring service.</span>
        </div>
      </div>
    </footer>
  );
};

import React, { useState, useEffect } from 'react';
import { PageId } from '../types';
import { TUTORIA_CONFIG } from '../data';

interface HeaderProps {
  currentPage: PageId;
  onNavigate: (page: PageId, hash?: string) => void;
  buildWhatsAppUrl: (message?: string) => string;
}

export const Header: React.FC<HeaderProps> = ({ currentPage, onNavigate, buildWhatsAppUrl }) => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [headerHidden, setHeaderHidden] = useState(false);

  useEffect(() => {
    let lastY = window.scrollY;
    const threshold = 6;
    const revealZone = 80;

    const handleScroll = () => {
      const currentY = window.scrollY;
      const diff = currentY - lastY;

      if (currentY <= revealZone || menuOpen) {
        setHeaderHidden(false);
      } else if (diff > threshold) {
        setHeaderHidden(true);
      } else if (diff < -threshold) {
        setHeaderHidden(false);
      }
      lastY = currentY;
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [menuOpen]);

  const handleNavClick = (page: PageId) => {
    onNavigate(page);
    setMenuOpen(false);
  };

  return (
    <header className={`site-header ${headerHidden ? 'header-hidden' : ''}`} id="siteHeader">
      <div className="container">
        <div className="brand" onClick={() => handleNavClick('home')} role="button" tabIndex={0}>
          <img src="/logo.svg" alt="Tutoria" />
        </div>

        <nav className={`main-nav ${menuOpen ? 'open' : ''}`} id="mainNav">
          <button
            type="button"
            className={currentPage === 'home' ? 'active' : ''}
            onClick={() => handleNavClick('home')}
          >
            Home
          </button>
          <button
            type="button"
            className={currentPage === 'join-as-tutor' || currentPage === 'apply' ? 'active' : ''}
            onClick={() => handleNavClick('join-as-tutor')}
          >
            Join as Tutor
          </button>
          <button
            type="button"
            className={currentPage === 'contact' ? 'active' : ''}
            onClick={() => handleNavClick('contact')}
          >
            Contact
          </button>
          <button
            type="button"
            className={currentPage === 'review' ? 'active' : ''}
            onClick={() => handleNavClick('review')}
          >
            Leave a Review
          </button>
        </nav>

        <div className="header-cta">
          <a
            href={buildWhatsAppUrl("Hi Tutoria, I'd like to get in touch.")}
            target="_blank"
            rel="noopener noreferrer"
            className="btn btn-whatsapp btn-lg"
          >
            <svg viewBox="0 0 32 32" aria-hidden="true">
              <path
                fill="currentColor"
                d="M16.001 3C9.096 3 3.5 8.596 3.5 15.5c0 2.42.67 4.68 1.83 6.61L3 29l7.06-2.28a12.44 12.44 0 0 0 5.94 1.52h.01c6.9 0 12.5-5.6 12.5-12.5S22.9 3 16 3Zm0 22.6h-.01a10.4 10.4 0 0 1-5.31-1.46l-.38-.22-4.19 1.35 1.37-4.08-.25-.42a10.36 10.36 0 0 1-1.6-5.5c0-5.75 4.68-10.43 10.44-10.43 2.79 0 5.41 1.09 7.38 3.06a10.35 10.35 0 0 1 3.05 7.37c0 5.75-4.69 10.43-10.5 10.43Zm5.72-7.8c-.31-.16-1.85-.91-2.14-1.02-.29-.1-.5-.16-.71.16-.21.31-.81 1.02-1 1.23-.18.21-.37.23-.68.08-.31-.16-1.32-.49-2.51-1.55-.93-.83-1.56-1.86-1.74-2.17-.18-.31-.02-.48.14-.63.14-.14.31-.37.47-.55.16-.19.21-.31.31-.52.1-.21.05-.39-.03-.55-.08-.16-.71-1.71-.97-2.34-.26-.62-.52-.53-.71-.54h-.6c-.21 0-.55.08-.84.39-.29.31-1.1 1.08-1.1 2.62 0 1.55 1.13 3.05 1.29 3.26.16.21 2.22 3.39 5.38 4.75.75.32 1.34.51 1.8.66.76.24 1.44.21 1.99.13.61-.09 1.85-.76 2.11-1.49.26-.73.26-1.36.18-1.49-.08-.13-.29-.21-.6-.37Z"
              />
            </svg>
            <span className="wa-label">WhatsApp Us</span>
          </a>

          <button
            type="button"
            className={`nav-toggle ${menuOpen ? 'active' : ''}`}
            onClick={() => setMenuOpen(!menuOpen)}
            aria-label={menuOpen ? 'Close navigation menu' : 'Open navigation menu'}
            aria-expanded={menuOpen}
          >
            <span className="hamburger-icon" aria-hidden="true">
              <span className="hamburger-bar bar-top"></span>
              <span className="hamburger-bar bar-mid"></span>
              <span className="hamburger-bar bar-bot"></span>
            </span>
          </button>
        </div>
      </div>
      {menuOpen && (
        <div
          className="mobile-nav-backdrop"
          onClick={() => setMenuOpen(false)}
          aria-hidden="true"
        />
      )}
    </header>
  );
};

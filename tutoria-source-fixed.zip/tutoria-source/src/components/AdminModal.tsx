import React, { useState } from 'react';
import { Testimonial, PendingReview, AreaRequest, TutorApplication } from '../types';
import { TUTORIA_CONFIG } from '../data';

interface AdminModalProps {
  isOpen: boolean;
  onClose: () => void;
  testimonials: Testimonial[];
  pendingReviews: PendingReview[];
  areaRequests: AreaRequest[];
  tutorApplications?: TutorApplication[];
  onAddTestimonial: (testimonial: Testimonial) => void;
  onRemoveTestimonial: (index: number) => void;
  onApprovePending: (index: number) => void;
  onRejectPending: (index: number) => void;
  onRemoveAreaRequest: (id: string) => void;
  onToggleAreaRequestStatus: (id: string) => void;
  onRemoveTutorApplication?: (id: string) => void;
  onToggleTutorApplicationStatus?: (id: string) => void;
}

export const AdminModal: React.FC<AdminModalProps> = ({
  isOpen,
  onClose,
  testimonials,
  pendingReviews,
  areaRequests,
  tutorApplications = [],
  onAddTestimonial,
  onRemoveTestimonial,
  onApprovePending,
  onRejectPending,
  onRemoveAreaRequest,
  onToggleAreaRequestStatus,
  onRemoveTutorApplication,
  onToggleTutorApplicationStatus,
}) => {
  const [password, setPassword] = useState('');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [hasError, setHasError] = useState(false);
  const [statusMessage, setStatusMessage] = useState('');
  const [activeTab, setActiveTab] = useState<'applications' | 'requests' | 'reviews' | 'testimonials'>('applications');

  // Form states
  const [name, setName] = useState('');
  const [meta, setMeta] = useState('');
  const [quote, setQuote] = useState('');
  const [rating, setRating] = useState('5 / 5');

  if (!isOpen) return null;

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === TUTORIA_CONFIG.adminPassword) {
      setIsAuthenticated(true);
      setHasError(false);
    } else {
      setHasError(true);
    }
  };

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !quote.trim()) return;

    onAddTestimonial({
      name: name.trim(),
      meta: meta.trim() || 'Verified Student / Parent',
      quote: quote.trim(),
      rating,
    });

    setName('');
    setMeta('');
    setQuote('');
    setStatusMessage('Added! Live on the site now.');
    setTimeout(() => setStatusMessage(''), 4000);
  };

  return (
    <div
      className="admin-overlay open"
      id="adminOverlay"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="admin-panel" role="dialog" aria-modal="true">
        <button type="button" className="admin-close" id="adminClose" onClick={onClose} aria-label="Close">
          ×
        </button>
        <h3>Manage Testimonials</h3>

        {!isAuthenticated ? (
          <form id="adminLogin" onSubmit={handleLogin}>
            <p className="sub">Enter the admin password to edit testimonials.</p>
            <div className="field">
              <input
                type="password"
                id="adminPw"
                placeholder="Password (default: tutoria2026)"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoFocus
              />
            </div>
            <button type="submit" className="btn btn-primary btn-sm" id="adminPwSubmit">
              Unlock
            </button>
            {hasError && (
              <p className="admin-status" id="adminPwError" style={{ color: '#f87171', marginTop: '10px' }}>
                Incorrect password.
              </p>
            )}
          </form>
        ) : (
          <div id="adminPanelBody">
            <div
              style={{
                background: '#161616',
                border: '1px solid var(--stone-800)',
                borderRadius: '10px',
                padding: '12px 16px',
                marginBottom: '20px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                gap: '12px',
              }}
            >
              <div>
                <p style={{ fontWeight: 600, color: 'var(--stone-100)', fontSize: '.88rem' }}>
                  Project Source Code (.ZIP)
                </p>
                <p style={{ color: 'var(--stone-400)', fontSize: '.78rem' }}>
                  Download all files ready for GitHub
                </p>
              </div>
              <a
                href="/tutoria-source.zip"
                download="tutoria-source.zip"
                className="btn btn-primary btn-sm"
                style={{
                  textDecoration: 'none',
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '6px',
                  whiteSpace: 'nowrap',
                }}
              >
                <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3" />
                </svg>
                Download ZIP
              </a>
            </div>

            {/* Admin navigation tabs */}
            <div
              style={{
                display: 'flex',
                gap: '8px',
                marginBottom: '20px',
                borderBottom: '1px solid var(--stone-800)',
                paddingBottom: '12px',
                overflowX: 'auto',
              }}
            >
              <button
                type="button"
                onClick={() => setActiveTab('applications')}
                style={{
                  background: activeTab === 'applications' ? 'rgba(245, 158, 11, 0.15)' : 'transparent',
                  border: activeTab === 'applications' ? '1px solid rgba(245, 158, 11, 0.4)' : '1px solid transparent',
                  color: activeTab === 'applications' ? '#F59E0B' : 'var(--stone-400)',
                  padding: '6px 14px',
                  borderRadius: '8px',
                  fontSize: '0.82rem',
                  fontWeight: 600,
                  cursor: 'pointer',
                  whiteSpace: 'nowrap',
                }}
              >
                Tutor Applications ({tutorApplications.length})
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('requests')}
                style={{
                  background: activeTab === 'requests' ? 'rgba(245, 158, 11, 0.15)' : 'transparent',
                  border: activeTab === 'requests' ? '1px solid rgba(245, 158, 11, 0.4)' : '1px solid transparent',
                  color: activeTab === 'requests' ? '#F59E0B' : 'var(--stone-400)',
                  padding: '6px 14px',
                  borderRadius: '8px',
                  fontSize: '0.82rem',
                  fontWeight: 600,
                  cursor: 'pointer',
                  whiteSpace: 'nowrap',
                }}
              >
                Area Requests ({areaRequests.length})
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('reviews')}
                style={{
                  background: activeTab === 'reviews' ? 'rgba(245, 158, 11, 0.15)' : 'transparent',
                  border: activeTab === 'reviews' ? '1px solid rgba(245, 158, 11, 0.4)' : '1px solid transparent',
                  color: activeTab === 'reviews' ? '#F59E0B' : 'var(--stone-400)',
                  padding: '6px 14px',
                  borderRadius: '8px',
                  fontSize: '0.82rem',
                  fontWeight: 600,
                  cursor: 'pointer',
                  whiteSpace: 'nowrap',
                }}
              >
                Pending Reviews ({pendingReviews.length})
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('testimonials')}
                style={{
                  background: activeTab === 'testimonials' ? 'rgba(245, 158, 11, 0.15)' : 'transparent',
                  border: activeTab === 'testimonials' ? '1px solid rgba(245, 158, 11, 0.4)' : '1px solid transparent',
                  color: activeTab === 'testimonials' ? '#F59E0B' : 'var(--stone-400)',
                  padding: '6px 14px',
                  borderRadius: '8px',
                  fontSize: '0.82rem',
                  fontWeight: 600,
                  cursor: 'pointer',
                  whiteSpace: 'nowrap',
                }}
              >
                Live Testimonials ({testimonials.length})
              </button>
            </div>

            {/* TAB 0: Tutor Applications */}
            {activeTab === 'applications' && (
              <div>
                <p className="sub" style={{ marginBottom: '14px' }}>
                  Tutors who applied directly via the website application form.
                </p>
                {tutorApplications.length === 0 ? (
                  <div style={{ padding: '30px 10px', textAlign: 'center', color: 'var(--stone-500)' }}>
                    <svg viewBox="0 0 24 24" width="32" height="32" fill="none" stroke="currentColor" strokeWidth="1.5" style={{ margin: '0 auto 8px', display: 'block' }}>
                      <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
                      <circle cx="9" cy="7" r="4" />
                      <path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" />
                    </svg>
                    No tutor applications submitted yet.
                  </div>
                ) : (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                    {tutorApplications.map((app) => (
                      <div
                        key={app.id}
                        style={{
                          background: '#181818',
                          border: '1px solid var(--stone-800)',
                          borderRadius: '10px',
                          padding: '14px',
                          display: 'flex',
                          flexDirection: 'column',
                          gap: '8px',
                        }}
                      >
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: '10px' }}>
                          <div>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
                              <span style={{ color: '#F59E0B', fontWeight: 700, fontSize: '0.96rem' }}>
                                👨‍🏫 {app.name}
                              </span>
                              <span
                                style={{
                                  fontSize: '0.72rem',
                                  padding: '2px 8px',
                                  borderRadius: '999px',
                                  fontWeight: 600,
                                  background:
                                    app.status === 'Verified'
                                      ? 'rgba(34, 197, 94, 0.2)'
                                      : app.status === 'Contacted'
                                      ? 'rgba(59, 130, 246, 0.2)'
                                      : 'rgba(245, 158, 11, 0.2)',
                                  color:
                                    app.status === 'Verified'
                                      ? '#4ade80'
                                      : app.status === 'Contacted'
                                      ? '#60a5fa'
                                      : '#fbbf24',
                                  border: `1px solid ${
                                    app.status === 'Verified'
                                      ? 'rgba(34, 197, 94, 0.3)'
                                      : app.status === 'Contacted'
                                      ? 'rgba(59, 130, 246, 0.3)'
                                      : 'rgba(245, 158, 11, 0.3)'
                                  }`,
                                }}
                              >
                                {app.status || 'Pending'}
                              </span>
                            </div>
                            <div style={{ color: 'var(--stone-300)', fontSize: '0.84rem', marginTop: '4px' }}>
                              📞 <strong>{app.phone}</strong> &bull; 📍 {app.area}
                            </div>
                          </div>

                          <span style={{ fontSize: '0.74rem', color: 'var(--stone-500)', whiteSpace: 'nowrap' }}>
                            {new Date(app.submittedAt).toLocaleDateString()}
                          </span>
                        </div>

                        <div
                          style={{
                            background: '#111111',
                            padding: '10px 12px',
                            borderRadius: '6px',
                            fontSize: '0.82rem',
                            color: 'var(--stone-300)',
                            display: 'flex',
                            flexDirection: 'column',
                            gap: '4px',
                          }}
                        >
                          <div><strong>Subjects:</strong> {app.subjects} ({app.grades})</div>
                          <div><strong>Qualification:</strong> {app.qualification} ({app.experience} yrs exp)</div>
                          {app.notes && <div><strong>Notes:</strong> {app.notes}</div>}
                        </div>

                        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '8px', marginTop: '4px' }}>
                          {onToggleTutorApplicationStatus && (
                            <button
                              type="button"
                              onClick={() => onToggleTutorApplicationStatus(app.id)}
                              style={{
                                background: 'rgba(245, 158, 11, 0.1)',
                                border: '1px solid rgba(245, 158, 11, 0.3)',
                                color: '#F59E0B',
                                fontSize: '0.76rem',
                                padding: '4px 10px',
                                borderRadius: '6px',
                                cursor: 'pointer',
                              }}
                            >
                              Status: {app.status === 'Pending' ? 'Mark Contacted' : app.status === 'Contacted' ? 'Mark Verified' : 'Mark Pending'}
                            </button>
                          )}
                          {onRemoveTutorApplication && (
                            <button
                              type="button"
                              onClick={() => onRemoveTutorApplication(app.id)}
                              style={{
                                background: 'rgba(239, 68, 68, 0.1)',
                                border: '1px solid rgba(239, 68, 68, 0.3)',
                                color: '#EF4444',
                                fontSize: '0.76rem',
                                padding: '4px 10px',
                                borderRadius: '6px',
                                cursor: 'pointer',
                              }}
                            >
                              Delete
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* TAB 1: Area & Tutor Requests */}
            {activeTab === 'requests' && (
              <div>
                <p className="sub" style={{ marginBottom: '14px' }}>
                  Incoming tutor applications submitted directly from the website without WhatsApp.
                </p>
                {areaRequests.length === 0 ? (
                  <div style={{ padding: '30px 10px', textAlign: 'center', color: 'var(--stone-500)' }}>
                    <svg viewBox="0 0 24 24" width="32" height="32" fill="none" stroke="currentColor" strokeWidth="1.5" style={{ margin: '0 auto 8px', display: 'block' }}>
                      <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" />
                      <circle cx="12" cy="10" r="3" />
                    </svg>
                    No custom area requests submitted yet.
                  </div>
                ) : (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                    {areaRequests.map((req) => (
                      <div
                        key={req.id}
                        style={{
                          background: '#181818',
                          border: '1px solid var(--stone-800)',
                          borderRadius: '10px',
                          padding: '14px',
                          display: 'flex',
                          flexDirection: 'column',
                          gap: '6px',
                        }}
                      >
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: '10px' }}>
                          <div>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
                              <span style={{ color: '#F59E0B', fontWeight: 700, fontSize: '0.94rem' }}>
                                📍 {req.area}
                              </span>
                              <span style={{ fontFamily: 'monospace', fontSize: '0.74rem', background: '#262626', color: '#a8a29e', padding: '2px 6px', borderRadius: '4px' }}>
                                {req.id}
                              </span>
                              <span
                                style={{
                                  fontSize: '0.72rem',
                                  padding: '2px 8px',
                                  borderRadius: '999px',
                                  background: req.status === 'Contacted' ? 'rgba(52, 211, 153, 0.15)' : req.status === 'Assigned' ? 'rgba(56, 189, 248, 0.15)' : 'rgba(245, 158, 11, 0.15)',
                                  color: req.status === 'Contacted' ? '#34d399' : req.status === 'Assigned' ? '#38bdf8' : '#fbbf24',
                                  border: '1px solid currentColor',
                                }}
                              >
                                {req.status || 'Pending'}
                              </span>
                            </div>
                            <div style={{ color: '#ffffff', fontSize: '0.88rem', fontWeight: 600, marginTop: '4px' }}>
                              📞 {req.phone} {req.name ? `(${req.name})` : ''}
                            </div>
                          </div>

                          <div style={{ display: 'flex', gap: '6px' }}>
                            <button
                              type="button"
                              onClick={() => onToggleAreaRequestStatus(req.id)}
                              style={{
                                background: '#262626',
                                border: '1px solid #404040',
                                color: '#e5e5e5',
                                padding: '4px 8px',
                                borderRadius: '6px',
                                fontSize: '0.74rem',
                                cursor: 'pointer',
                              }}
                              title="Cycle Status"
                            >
                              Status ⟳
                            </button>
                            <button
                              type="button"
                              onClick={() => onRemoveAreaRequest(req.id)}
                              style={{
                                color: '#f87171',
                                background: '#2c0b0e',
                                border: '1px solid #7f1d1d',
                                padding: '4px 8px',
                                borderRadius: '6px',
                                fontSize: '0.74rem',
                                cursor: 'pointer',
                              }}
                            >
                              Delete
                            </button>
                          </div>
                        </div>

                        <div style={{ fontSize: '0.82rem', color: '#a8a29e', marginTop: '4px', lineHeight: 1.5 }}>
                          <div>📚 <strong>Class / Exam:</strong> {req.classOrExam}</div>
                          <div>🎯 <strong>Type:</strong> {req.tutoringType}</div>
                          {req.notes && <div>📝 <strong>Notes:</strong> {req.notes}</div>}
                          <div style={{ fontSize: '0.72rem', color: '#737373', marginTop: '2px' }}>
                            Submitted: {req.submittedAt}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* TAB 2: Visitor Reviews */}
            {activeTab === 'reviews' && (
              <div>
                <p className="sub">Visitor-submitted reviews awaiting approval.</p>
                <div id="adminPendingList" style={{ marginTop: '12px' }}>
                  {pendingReviews.length === 0 ? (
                    <p className="testi-empty" style={{ color: 'var(--stone-500)' }}>
                      No pending reviews.
                    </p>
                  ) : (
                    pendingReviews.map((item, i) => (
                      <div className="admin-list-item" key={item.id || i}>
                        <div className="txt">
                          <b>{item.name}</b> — {item.meta}
                          <div style={{ color: '#F59E0B', fontSize: '0.8rem', margin: '2px 0' }}>
                            Rating: {item.rating || '5 / 5'}
                          </div>
                          <p style={{ marginTop: '4px' }}>{item.quote}</p>
                        </div>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                          <button
                            type="button"
                            style={{ color: '#34d399', background: '#062817', border: '1px solid #064e3b', padding: '4px 10px', borderRadius: '6px' }}
                            onClick={() => onApprovePending(i)}
                          >
                            Approve
                          </button>
                          <button
                            type="button"
                            style={{ color: '#f87171', background: '#2c0b0e', border: '1px solid #7f1d1d', padding: '4px 10px', borderRadius: '6px' }}
                            onClick={() => onRejectPending(i)}
                          >
                            Reject
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}

            {/* TAB 3: Manage Testimonials */}
            {activeTab === 'testimonials' && (
              <div>
                <p className="sub">Add or remove testimonials — changes go live immediately.</p>

                <form onSubmit={handleAdd}>
                  <div className="field">
                    <label>Parent / Student / Tutor name</label>
                    <input
                      type="text"
                      id="tName"
                      placeholder="e.g. Sohini Banerjee"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      required
                    />
                  </div>

                  <div className="field">
                    <label>Detail line</label>
                    <input
                      type="text"
                      id="tMeta"
                      placeholder="e.g. Parent of Class 9 (ICSE), Salt Lake"
                      value={meta}
                      onChange={(e) => setMeta(e.target.value)}
                    />
                  </div>

                  <div className="field">
                    <label>Rating</label>
                    <select value={rating} onChange={(e) => setRating(e.target.value)}>
                      <option value="5 / 5">5 / 5 Stars</option>
                      <option value="4 / 5">4 / 5 Stars</option>
                      <option value="3 / 5">3 / 5 Stars</option>
                    </select>
                  </div>

                  <div className="field">
                    <label>Testimonial</label>
                    <textarea
                      id="tQuote"
                      placeholder="What they said..."
                      value={quote}
                      onChange={(e) => setQuote(e.target.value)}
                      required
                    />
                  </div>

                  <button type="submit" className="btn btn-primary btn-sm" id="tAdd">
                    Add Testimonial
                  </button>
                  {statusMessage && <p className="admin-status">{statusMessage}</p>}
                </form>

                <h4
                  style={{
                    marginTop: '26px',
                    fontFamily: 'var(--font-body)',
                    fontSize: '.78rem',
                    letterSpacing: '.08em',
                    textTransform: 'uppercase',
                    color: 'var(--stone-400)',
                  }}
                >
                  Published on site ({testimonials.length})
                </h4>
                <div id="adminList" style={{ marginTop: '12px' }}>
                  {testimonials.length === 0 ? (
                    <p className="testi-empty" style={{ color: 'var(--stone-500)' }}>
                      No published testimonials.
                    </p>
                  ) : (
                    testimonials.map((item, i) => (
                      <div className="admin-list-item" key={item.id || i}>
                        <div className="txt">
                          <b>{item.name}</b> — {item.meta}
                          <p style={{ marginTop: '4px' }}>{item.quote}</p>
                        </div>
                        <button
                          type="button"
                          style={{ color: '#f87171', background: '#2c0b0e', border: '1px solid #7f1d1d', padding: '4px 10px', borderRadius: '6px' }}
                          onClick={() => onRemoveTestimonial(i)}
                        >
                          Remove
                        </button>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

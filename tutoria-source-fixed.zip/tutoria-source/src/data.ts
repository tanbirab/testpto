import { Testimonial, BoardLevel, StepItem, WhyFeature, FaqItem } from './types';

export const TUTORIA_CONFIG = {
  whatsappNumber: '918368003189',
  whatsappDefaultMessage: "Hi Tutoria, I'd like to book a free demo class.",
  adminPassword: 'tutoria2026',
  email: 'info@tutoria.in',
  phoneDisplay: '8368003189',
  serviceArea: 'West Bengal — Kolkata and nearby districts',
  hours: 'Mon – Sat, 9:00 AM – 8:00 PM',
};

export const DEFAULT_TESTIMONIALS: Testimonial[] = [
  {
    name: 'Sohini Banerjee',
    meta: 'Parent of Class 9 (ICSE), Salt Lake',
    quote: 'Our tutor understood exactly where my son was struggling in Maths. Three months in, his confidence before exams has completely changed.',
    rating: '5 / 5',
  },
  {
    name: 'Aritra Chowdhury',
    meta: 'Student, Class 12 (WBCHSE), Jadavpur',
    quote: 'My Physics and Maths tutor through Tutoria actually explains concepts instead of rushing through the syllabus. I finally look forward to boards prep instead of dreading it.',
    rating: '5 / 5',
  },
  {
    name: 'Debolina Ghosh',
    meta: 'Tutor, Maths & Science, Behala',
    quote: 'I signed up expecting a slow trickle of leads, but Tutoria matched me with students that genuinely fit my subjects and area within days — and the payments have always been on time.',
    rating: '5 / 5',
  },
];

export const BOARDS_DATA: BoardLevel[] = [
  {
    tag: 'Foundation',
    title: 'KG – Class 5',
    desc: 'Building strong basics in reading, writing and number sense.',
    icon: 'book',
    colorClass: 'board-card--1',
  },
  {
    tag: 'Middle School',
    title: 'Class 6 – 8',
    desc: 'Subject-wise support as coursework becomes more demanding.',
    icon: 'edit',
    colorClass: 'board-card--2',
  },
  {
    tag: 'Secondary',
    title: 'Class 9 – 10',
    desc: 'Board-exam focused preparation for CBSE, ICSE and WBBSE.',
    icon: 'target',
    colorClass: 'board-card--3',
  },
  {
    tag: 'Higher Secondary',
    title: 'Class 11 – 12',
    desc: 'Stream-specific tutoring for WBCHSE, CBSE and ICSE.',
    icon: 'trending',
    colorClass: 'board-card--4',
  },
];

export const HOW_IT_WORKS_STEPS: StepItem[] = [
  {
    step: 'Step 01',
    title: 'Message on WhatsApp',
    desc: "Share your child's class, subject and area — it takes under two minutes.",
    icon: 'message',
    colorClass: 'how-card--1',
  },
  {
    step: 'Step 02',
    title: 'We Shortlist a Tutor',
    desc: "Based on syllabus, experience, and your child's unique learning pace.",
    icon: 'search',
    colorClass: 'how-card--2',
  },
  {
    step: 'Step 03',
    title: 'Attend a Free Demo',
    desc: 'Meet the tutor in a real session before deciding anything.',
    icon: 'calendar',
    colorClass: 'how-card--3',
  },
  {
    step: 'Step 04',
    title: 'Start Regular Classes',
    desc: 'Pick a schedule that works and begin, with monthly progress updates.',
    icon: 'rocket',
    colorClass: 'how-card--4',
  },
];

export const WHY_TUTORIA_FEATURES: WhyFeature[] = [
  {
    tag: 'Trusted Tutors',
    title: 'Verified & Checked',
    desc: 'Every tutor completes ID verification and a subject-knowledge check before we recommend them.',
    icon: 'shield',
    colorClass: 'why-card--1',
  },
  {
    tag: 'Smart Matching',
    title: 'Matched, Not Searched',
    desc: "Tell us your child's needs on WhatsApp — we shortlist the right tutor instead of making endless calls.",
    icon: 'users',
    colorClass: 'why-card--2',
  },
  {
    tag: 'Risk-Free Trial',
    title: 'Free Demo Class',
    desc: 'See how a tutor teaches before committing, with zero pressure and no obligation.',
    icon: 'play',
    colorClass: 'why-card--3',
  },
  {
    tag: 'Flexible Guarantee',
    title: 'Free Replacement',
    desc: 'Not the right fit? We will find a new tutor at no extra cost, no questions asked.',
    icon: 'refresh',
    colorClass: 'why-card--4',
  },
];

export const AREAS_LIST = [
  'Salt Lake',
  'New Town',
  'Ballygunge',
  'Behala',
  'Garia',
  'Howrah',
  'Dum Dum',
  'Rajarhat',
  'Tollygunge',
  'Jadavpur',
  'Durgapur',
  'Asansol',
  'Siliguri',
];

export const HOME_FAQS: FaqItem[] = [
  {
    q: 'Which boards do you cover?',
    a: 'CBSE, ICSE, the WB Board (WBBSE and WBCHSE), and select IGCSE or IB requests on a case-by-case basis.',
  },
  {
    q: 'Is the first class really free?',
    a: 'Yes. Every match starts with a free demo class so you can evaluate the tutor before paying anything.',
  },
  {
    q: 'Can I request a different tutor?',
    a: 'Absolutely — we offer a free replacement anytime you are not fully satisfied.',
  },
  {
    q: 'Do you offer online classes too?',
    a: 'Our core offering is home tutoring, but we can arrange online sessions where preferred.',
  },
  {
    q: 'How do I get started?',
    a: 'Tap "WhatsApp Us" and tell us your child\'s class, subject and area — we will take it from there.',
  },
];

export const TUTOR_FAQS: FaqItem[] = [
  {
    q: 'Do I need prior teaching experience?',
    a: 'It helps, but strong subject knowledge and a relevant qualification matter most, especially for foundational grades.',
  },
  {
    q: 'How much can I earn?',
    a: 'Pay depends on grade level, subject and experience. We will share exact rates during verification.',
  },
  {
    q: 'Is there a fee to join?',
    a: 'No. Registering with Tutoria as a tutor is completely free.',
  },
  {
    q: 'How much is the consultancy charge?',
    a: "Our fee is one month's tuition fee, paid in two instalments — 50% + 50%. No hidden charges, no surprises.",
  },
];

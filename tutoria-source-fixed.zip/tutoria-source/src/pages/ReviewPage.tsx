import React, { useState } from 'react';
import { PageId, PendingReview } from '../types';

interface ReviewPageProps {
  onSubmitReview: (review: PendingReview) => void;
  onNavigate: (page: PageId) => void;
}

export const ReviewPage: React.FC<ReviewPageProps> = ({ onSubmitReview, onNavigate }) => {
  const [formData, setFormData] = useState({
    name: '',
    role: 'Parent',
    classGrade: '',
    area: '',
    rating: '5 / 5',
    feedback: '',
  });

  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const metaParts = [formData.role];
    if (formData.classGrade) metaParts.push(formData.classGrade);
    if (formData.area) metaParts.push(formData.area);

    const newReview: PendingReview = {
      id: Date.now().toString(),
      name: formData.name.trim(),
      meta: metaParts.join(', '),
      quote: formData.feedback.trim(),
      rating: formData.rating,
      submittedAt: new Date().toISOString(),
    };

    onSubmitReview(newReview);
    setIsSubmitted(true);
  };

  return (
    <div className="page-review">
      <section className="hero-review hero-full">
        <div className="hero-review-grid">
          <div className="hero-review-text">
            <p className="hero-review-eyebrow">Feedback</p>
            <h1 className="hero-review-title">
              How was your experience<span>?</span>
            </h1>
            <p className="hero-review-lead">
              Your feedback helps other parents choose with confidence, and helps us continuously improve. Approved
              reviews are featured on our homepage.
            </p>
            <div className="hero-review-trust">
              <span className="hero-review-stars" aria-hidden="true">
                ★★★★★
              </span>
              <span>Loved by 1,000+ Kolkata families</span>
            </div>
          </div>

          <div className="hero-review-card">
            {!isSubmitted ? (
              <>
                <h2 className="hero-review-card-title">Share your thoughts</h2>
                <p className="hero-review-card-sub">It takes less than 2 minutes to fill out this form.</p>

                <form className="hero-review-form" id="reviewForm" onSubmit={handleSubmit}>
                  <div className="hero-review-row">
                    <div className="hero-review-field">
                      <label htmlFor="revName">Your name</label>
                      <input
                        id="revName"
                        type="text"
                        name="name"
                        placeholder="e.g. Srikant Mukherjee"
                        value={formData.name}
                        onChange={handleChange}
                        required
                      />
                    </div>
                    <div className="hero-review-field">
                      <label htmlFor="revRole">I am a</label>
                      <select id="revRole" name="role" value={formData.role} onChange={handleChange}>
                        <option value="Parent">Parent</option>
                        <option value="Student">Student</option>
                        <option value="Tutor">Tutor</option>
                      </select>
                    </div>
                  </div>

                  <div className="hero-review-row">
                    <div className="hero-review-field">
                      <label htmlFor="revClass">Class / Grade (if applicable)</label>
                      <input
                        id="revClass"
                        type="text"
                        name="classGrade"
                        placeholder="e.g. Class 9, ICSE"
                        value={formData.classGrade}
                        onChange={handleChange}
                      />
                    </div>
                    <div className="hero-review-field">
                      <label htmlFor="revArea">Area</label>
                      <input
                        id="revArea"
                        type="text"
                        name="area"
                        placeholder="e.g. Salt Lake, Kolkata"
                        value={formData.area}
                        onChange={handleChange}
                      />
                    </div>
                  </div>

                  <div className="hero-review-field">
                    <label htmlFor="revRating">Rating</label>
                    <select id="revRating" name="rating" value={formData.rating} onChange={handleChange}>
                      <option value="5 / 5">★★★★★ — Excellent</option>
                      <option value="4 / 5">★★★★☆ — Good</option>
                      <option value="3 / 5">★★★☆☆ — Okay</option>
                      <option value="2 / 5">★★☆☆☆ — Below Average</option>
                      <option value="1 / 5">★☆☆☆☆ — Poor</option>
                    </select>
                  </div>

                  <div className="hero-review-field hero-review-field-message">
                    <label htmlFor="revFeedback">Your feedback</label>
                    <textarea
                      id="revFeedback"
                      name="feedback"
                      placeholder="Tell us about your experience with your tutor and with Tutoria..."
                      value={formData.feedback}
                      onChange={handleChange}
                      required
                    ></textarea>
                  </div>

                  <button type="submit" className="hero-review-submit">
                    Submit Review
                  </button>
                  <p className="hero-review-note">
                    Reviews are checked before appearing on the site — this usually takes a day or two.
                  </p>
                </form>
              </>
            ) : (
              <div className="hero-review-confirm" id="reviewConfirm">
                <h3>Thank you!</h3>
                <p>
                  Your review has been submitted and is awaiting approval. We appreciate you taking the time to share your
                  experience.
                </p>
                <button
                  type="button"
                  className="btn btn-outline btn-sm"
                  onClick={() => onNavigate('home')}
                  style={{ marginTop: '20px' }}
                >
                  Back to Home
                </button>
              </div>
            )}
          </div>
        </div>
      </section>
    </div>
  );
};

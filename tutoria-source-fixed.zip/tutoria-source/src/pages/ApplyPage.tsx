import React, { useState } from 'react';
import { PageId, TutorApplication } from '../types';

interface ApplyPageProps {
  onOpenTerms: () => void;
  onNavigate?: (page: PageId) => void;
  onSubmitApplication?: (application: TutorApplication) => void;
}

export const ApplyPage: React.FC<ApplyPageProps> = ({
  onOpenTerms,
  onNavigate,
  onSubmitApplication,
}) => {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    qualification: '',
    experience: '',
    subjects: '',
    grades: '',
    area: '',
    notes: '',
    terms: false,
  });

  const [submittedData, setSubmittedData] = useState<TutorApplication | null>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value,
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.terms) {
      alert('Please agree to the Terms & Conditions to submit your application.');
      return;
    }

    const newApplication: TutorApplication = {
      id: 'app_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6),
      name: formData.name.trim(),
      phone: formData.phone.trim(),
      qualification: formData.qualification.trim(),
      experience: formData.experience.trim(),
      subjects: formData.subjects.trim(),
      grades: formData.grades.trim(),
      area: formData.area.trim(),
      notes: formData.notes.trim() || undefined,
      submittedAt: new Date().toISOString(),
      status: 'Pending',
    };

    if (onSubmitApplication) {
      onSubmitApplication(newApplication);
    }

    setSubmittedData(newApplication);
  };

  const handleReset = () => {
    setFormData({
      name: '',
      phone: '',
      qualification: '',
      experience: '',
      subjects: '',
      grades: '',
      area: '',
      notes: '',
      terms: false,
    });
    setSubmittedData(null);
  };

  return (
    <div className="page-apply">
      <section className="hero-apply hero-full">
        <div className="hero-apply-grid">
          <div className="hero-apply-text">
            <p className="eyebrow">For Tutors</p>
            <h1>
              Join as a Tutor &amp; Start Teaching<span>.</span>
            </h1>
            <p className="lead">
              Connect with students and parents in your area. Fill out your details to get verified and list your profile on
              our tutor marketplace.
            </p>
            <div className="hero-apply-bullets">
              <div className="hero-apply-bullet">
                <span className="dot" aria-hidden="true"></span>Verified Parent Leads
              </div>
              <div className="hero-apply-bullet">
                <span className="dot" aria-hidden="true"></span>Flexible Schedules
              </div>
              <div className="hero-apply-bullet">
                <span className="dot" aria-hidden="true"></span>Direct Home &amp; Online Tutoring
              </div>
            </div>
          </div>

          <div className="hero-apply-card">
            {submittedData ? (
              <div className="apply-success-view">
                <div className="apply-success-badge">
                  <svg viewBox="0 0 24 24" width="32" height="32" fill="none" stroke="#22c55e" strokeWidth="2.5">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                  </svg>
                </div>

                <h2 className="hero-apply-card-title text-center" style={{ marginBottom: '8px' }}>
                  Application Submitted!
                </h2>
                <p className="text-stone-300 text-sm text-center mb-6">
                  Thank you, <strong className="text-amber-400">{submittedData.name}</strong>. Your tutor application has been received.
                </p>

                <div className="apply-summary-card">
                  <div className="apply-summary-row">
                    <span className="label">Contact Phone:</span>
                    <span className="value">{submittedData.phone}</span>
                  </div>
                  <div className="apply-summary-row">
                    <span className="label">Preferred Location:</span>
                    <span className="value">{submittedData.area}</span>
                  </div>
                  <div className="apply-summary-row">
                    <span className="label">Subjects:</span>
                    <span className="value">{submittedData.subjects}</span>
                  </div>
                  <div className="apply-summary-row">
                    <span className="label">Classes / Grades:</span>
                    <span className="value">{submittedData.grades}</span>
                  </div>
                  <div className="apply-summary-row">
                    <span className="label">Qualification:</span>
                    <span className="value">{submittedData.qualification} ({submittedData.experience} yrs exp)</span>
                  </div>
                </div>

                <div className="hero-apply-verify" style={{ marginTop: '20px', marginBottom: '24px' }}>
                  <div className="hero-apply-verify-head">
                    <span className="hero-apply-verify-icon" aria-hidden="true">
                      <svg viewBox="0 0 24 24" width="16" height="16">
                        <circle cx="12" cy="12" r="12" fill="#F59E0B" />
                        <path d="M12 8v4M12 16h.01" stroke="#FFFFFF" strokeWidth="2" strokeLinecap="round" />
                      </svg>
                    </span>
                    <span>What Happens Next?</span>
                  </div>
                  <p>
                    Our academic coordinator team will review your credentials and contact you directly at{' '}
                    <strong>{submittedData.phone}</strong> within 24–48 hours for document verification and profile onboarding.
                  </p>
                </div>

                <div className="apply-success-actions">
                  {onNavigate && (
                    <button
                      type="button"
                      className="hero-apply-submit"
                      onClick={() => onNavigate('home')}
                      id="applyBackHomeBtn"
                    >
                      Back to Home
                    </button>
                  )}
                  <button
                    type="button"
                    className="area-modal-btn-cancel w-full justify-center mt-3"
                    onClick={handleReset}
                    id="applyAnotherBtn"
                  >
                    Submit Another Application
                  </button>
                </div>
              </div>
            ) : (
              <>
                <h2 className="hero-apply-card-title">Tutor Application Form</h2>

                <form className="hero-apply-form" id="tutorForm" onSubmit={handleSubmit}>
                  <div className="hero-apply-row">
                    <div className="hero-apply-field">
                      <label htmlFor="tutorName">Full Name</label>
                      <input
                        id="tutorName"
                        type="text"
                        name="name"
                        placeholder="Rahul Sharma"
                        value={formData.name}
                        onChange={handleChange}
                        required
                      />
                    </div>
                    <div className="hero-apply-field">
                      <label htmlFor="tutorPhone">Phone Number</label>
                      <input
                        id="tutorPhone"
                        type="tel"
                        name="phone"
                        placeholder="+91 98765 43210"
                        value={formData.phone}
                        onChange={handleChange}
                        required
                      />
                    </div>
                  </div>

                  <div className="hero-apply-row">
                    <div className="hero-apply-field">
                      <label htmlFor="tutorQual">Highest Qualification</label>
                      <input
                        id="tutorQual"
                        type="text"
                        name="qualification"
                        placeholder="M.Sc. in Physics"
                        value={formData.qualification}
                        onChange={handleChange}
                        required
                      />
                    </div>
                    <div className="hero-apply-field">
                      <label htmlFor="tutorExp">Years of Experience</label>
                      <input
                        id="tutorExp"
                        type="number"
                        name="experience"
                        min="0"
                        placeholder="5"
                        value={formData.experience}
                        onChange={handleChange}
                        required
                      />
                    </div>
                  </div>

                  <div className="hero-apply-row">
                    <div className="hero-apply-field">
                      <label htmlFor="tutorSubjects">Subjects You Teach</label>
                      <input
                        id="tutorSubjects"
                        type="text"
                        name="subjects"
                        placeholder="Mathematics, Science"
                        value={formData.subjects}
                        onChange={handleChange}
                        required
                      />
                    </div>
                    <div className="hero-apply-field">
                      <label htmlFor="tutorGrades">Classes / Grades Handled</label>
                      <input
                        id="tutorGrades"
                        type="text"
                        name="grades"
                        placeholder="Class 8–12 (ICSE/CBSE)"
                        value={formData.grades}
                        onChange={handleChange}
                        required
                      />
                    </div>
                  </div>

                  <div className="hero-apply-row">
                    <div className="hero-apply-field">
                      <label htmlFor="tutorArea">Preferred Area / Location</label>
                      <input
                        id="tutorArea"
                        type="text"
                        name="area"
                        placeholder="Salt Lake, Kolkata"
                        value={formData.area}
                        onChange={handleChange}
                        required
                      />
                    </div>
                    <div className="hero-apply-field">
                      <label htmlFor="tutorNotes">Anything else to share?</label>
                      <input
                        id="tutorNotes"
                        type="text"
                        name="notes"
                        placeholder="Available weekends..."
                        value={formData.notes}
                        onChange={handleChange}
                      />
                    </div>
                  </div>

                  <div className="hero-apply-verify">
                    <div className="hero-apply-verify-head">
                      <span className="hero-apply-verify-icon" aria-hidden="true">
                        <svg viewBox="0 0 24 24" width="16" height="16">
                          <circle cx="12" cy="12" r="12" fill="#F59E0B" />
                          <path d="M12 8v4M12 16h.01" stroke="#FFFFFF" strokeWidth="2" strokeLinecap="round" />
                        </svg>
                      </span>
                      <span>Document Verification Notice</span>
                    </div>
                    <p>
                      After submitting your application, our academic coordinator team will connect with you to verify your
                      academic qualifications and government-issued IDs. Please be prepared to share your credentials during verification.
                    </p>
                  </div>

                  <label className="hero-apply-terms" htmlFor="tutorTerms">
                    <input
                      type="checkbox"
                      name="terms"
                      id="tutorTerms"
                      checked={formData.terms}
                      onChange={handleChange}
                      required
                    />
                    <span className="hero-apply-check" aria-hidden="true">
                      <svg viewBox="0 0 16 16" width="11" height="11">
                        <path
                          d="M3 8.5l3 3 7-7"
                          stroke="#FFFFFF"
                          strokeWidth="2"
                          fill="none"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                      </svg>
                    </span>
                    <span>
                      I agree to the{' '}
                      <button type="button" className="hero-apply-terms-link" id="openTerms" onClick={onOpenTerms}>
                        Terms &amp; Conditions
                      </button>
                    </span>
                  </label>

                  <button type="submit" className="hero-apply-submit" id="tutorApplySubmitBtn">
                    <span>Submit Application</span>
                    <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2.5">
                      <path d="M5 12h14M12 5l7 7-7 7" />
                    </svg>
                  </button>
                </form>
              </>
            )}
          </div>
        </div>
      </section>
    </div>
  );
};

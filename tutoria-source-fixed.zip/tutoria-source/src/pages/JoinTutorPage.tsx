import React, { useState } from 'react';
import { PageId } from '../types';
import { TUTOR_FAQS } from '../data';

interface JoinTutorPageProps {
  onNavigate: (page: PageId) => void;
}

export const JoinTutorPage: React.FC<JoinTutorPageProps> = ({ onNavigate }) => {
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(null);

  const toggleFaq = (index: number) => {
    setOpenFaqIndex(openFaqIndex === index ? null : index);
  };

  return (
    <div className="page-join-tutor">
      {/* HERO */}
      <section className="hero hero-tutor hero-full">
        <div className="hero-tutor-grid">
          <div className="hero-tutor-card">
            <p className="hero-tutor-card-eyebrow">Why Teach With Tutoria</p>
            <h2 className="hero-tutor-card-title">Because Tutors Deserve Better</h2>
            <div className="hero-tutor-features">
              <div className="hero-tutor-feature">
                <span className="hero-tutor-dot" aria-hidden="true"></span>
                <div>
                  <h3>We Don't Treat Tutors Like Garbage.</h3>
                  <p>Some agencies forget that tutors are professionals. We don't.</p>
                </div>
              </div>
              <div className="hero-tutor-feature">
                <span className="hero-tutor-dot" aria-hidden="true"></span>
                <div>
                  <h3>We Don't Think We're Doing You a Favour.</h3>
                  <p>You teach. We connect you with students. It's a partnership, not a favour.</p>
                </div>
              </div>
              <div className="hero-tutor-feature">
                <span className="hero-tutor-dot" aria-hidden="true"></span>
                <div>
                  <h3>We Don't Talk Down to Tutors.</h3>
                  <p>You're not working for us. We're working with you.</p>
                </div>
              </div>
              <div className="hero-tutor-feature">
                <span className="hero-tutor-dot" aria-hidden="true"></span>
                <div>
                  <h3>We Know What Tutors Bring.</h3>
                  <p>Without good tutors, there is no Tutoria. Simple.</p>
                </div>
              </div>
            </div>
          </div>

          <div className="hero-full-text hero-tutor-text">
            <p className="eyebrow">For Tutors</p>
            <h1>
              Teach on your terms<span>.</span>
            </h1>
            <p className="lead">We handle the matching, you handle the teaching.</p>
            <div className="hero-ctas">
              <button
                type="button"
                className="btn btn-hero-tutor-primary btn-lg"
                onClick={() => onNavigate('apply')}
              >
                Apply Now
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section id="tutor-faq" className="faq-cinema-tutor">
        <div className="faq-cinema-tutor-frame">
          <div className="faq-cinema-tutor-header">
            <p className="faq-cinema-tutor-eyebrow">FAQs for Tutors</p>
            <h2 className="faq-cinema-tutor-title">Common questions</h2>
          </div>
          <div className="faq">
            {TUTOR_FAQS.map((faq, idx) => {
              const isOpen = openFaqIndex === idx;
              return (
                <div key={idx} className={`faq-item ${isOpen ? 'open' : ''}`}>
                  <button
                    type="button"
                    className="faq-q"
                    onClick={() => toggleFaq(idx)}
                    aria-expanded={isOpen}
                  >
                    <span>{faq.q}</span>
                    <span className="plus" aria-hidden="true">
                      <svg viewBox="0 0 20 20" width="20" height="20" fill="none">
                        <line
                          className="icon-v"
                          x1="10"
                          y1="0"
                          x2="10"
                          y2="20"
                          stroke="currentColor"
                          strokeWidth="2.5"
                          strokeLinecap="round"
                        />
                        <line
                          className="icon-h"
                          x1="0"
                          y1="10"
                          x2="20"
                          y2="10"
                          stroke="currentColor"
                          strokeWidth="2.5"
                          strokeLinecap="round"
                        />
                      </svg>
                    </span>
                  </button>
                  <div className="faq-a">
                    <p>{faq.a}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>
    </div>
  );
};

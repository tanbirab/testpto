import React, { useState } from 'react';
import { PageId, Testimonial } from '../types';
import {
  BOARDS_DATA,
  HOW_IT_WORKS_STEPS,
  WHY_TUTORIA_FEATURES,
  AREAS_LIST,
  HOME_FAQS,
} from '../data';

interface HomePageProps {
  onNavigate: (page: PageId, hash?: string) => void;
  buildWhatsAppUrl: (message?: string) => string;
  testimonials: Testimonial[];
  onOpenAreaRequest: () => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  onNavigate,
  buildWhatsAppUrl,
  testimonials,
  onOpenAreaRequest,
}) => {
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(null);

  const toggleFaq = (index: number) => {
    setOpenFaqIndex(openFaqIndex === index ? null : index);
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((w) => w[0])
      .slice(0, 2)
      .join('')
      .toUpperCase();
  };

  const renderStars = (ratingStr?: string) => {
    const filled = ratingStr ? Math.max(0, Math.min(5, parseInt(ratingStr, 10) || 5)) : 5;
    return (
      <div className="testi-stars">
        {[0, 1, 2, 3, 4].map((i) => (
          <svg
            key={i}
            className={`testi-star ${i < filled ? 'is-filled' : ''}`}
            viewBox="0 0 12 12"
            aria-hidden="true"
          >
            <path d="M6 0l1.8 3.7 4.1.6-3 2.9.7 4.1L6 9.3 2.4 11.3l.7-4.1-3-2.9 4.1-.6z" />
          </svg>
        ))}
      </div>
    );
  };

  return (
    <div className="page-home">
      {/* HERO */}
      <section className="hero hero-home hero-full">
        <div className="hero-full-grid">
          <div className="hero-full-text">
            <p className="eyebrow">Verified Home Tutors</p>
            <h1>
              Learning she
              <br />
              looks forward to<span>.</span>
            </h1>
            <p className="lead">Verified home tutors, KG to Class 12.</p>
            <div className="hero-ctas">
              <a
                href={buildWhatsAppUrl("Hi Tutoria, I'd like to book a free demo class.")}
                target="_blank"
                rel="noopener noreferrer"
                className="btn btn-whatsapp btn-lg"
              >
                <svg viewBox="0 0 32 32" aria-hidden="true">
                  <path
                    fill="currentColor"
                    d="M16.001 3C9.096 3 3.5 8.596 3.5 15.5c0 2.42.67 4.68 1.83 6.61L3 29l7.06-2.28a12.44 12.44 0 0 0 5.94 1.52h.01c6.9 0 12.5-5.6 12.5-12.5S22.9 3 16 3Zm0 22.6h-.01a10.4 10.4 0 0 1-5.31-1.46l-.38-.22-4.19 1.35 1.37-4.08-.25-.42a10.36 10.36 0 0 1-1.6-5.5c0-5.75 4.68-10.43 10.44-10.43 2.79 0 5.41 1.09 7.38 3.06a10.35 10.35 0 0 1 3.05 7.37c0 5.75-4.69 10.43-10.5 10.43Zm5.72-7.8c-.31-.16-1.85-.91-2.14-1.02-.29-.1-.5-.16-.71.16-.21.31-.81 1.02-1 1.23-.18.21-.37.23-.68.08-.31-.16-1.32-.49-2.51-1.55-.93-.83-1.56-1.86-1.74-2.17-.18-.31-.02-.48.14-.63.14-.14.31-.37.47-.55.16-.19.21-.31.31-.52.1-.21.05-.39-.03-.55-.08-.16-.71-1.71-.97-2.34-.26-.62-.52-.53-.71-.54h-.6c-.21 0-.55.08-.84.39-.29.31-1.1 1.08-1.1 2.62 0 1.55 1.13 3.05 1.29 3.26.16.21 2.22 3.39 5.38 4.75.75.32 1.34.51 1.8.66.76.24 1.44.21 1.99.13.61-.09 1.85-.76 2.11-1.49.26-.73.26-1.36.18-1.49-.08-.13-.29-.21-.6-.37Z"
                  />
                </svg>
                Book a Free Demo
              </a>
              <button
                type="button"
                className="btn btn-outline-light btn-lg"
                onClick={() => onNavigate('join-as-tutor')}
              >
                Become a Tutor
              </button>
            </div>
          </div>
          <div className="hero-full-image">
            <div className="hero-full-glow"></div>
            <img
              src="/hero-student.png"
              alt="Tutoria dedicated student"
            />
          </div>
        </div>
      </section>

      {/* OUR STORY */}
      <section className="story-section">
        <div className="container">
          <div className="story-head">
            <p className="eyebrow story-eyebrow">Our Story</p>
            <h2 className="story-heading">Why we started Tutoria</h2>
          </div>

          <div className="story-card">
            <div className="story-copy">
              <div className="story-block">
                <h3>The Vision &amp; Execution Behind Tutoria</h3>
                <p>
                  Tutoria was co-founded by two education enthusiasts — a conceptual research scholar from IISER Pune
                  and a pragmatic tech enthusiast from Calcutta University. Observing the challenges faced by parents
                  in major metros like Kolkata and Siliguri, they realized that even established private schools often
                  lack the necessary depth and personalized focus to help students truly excel.
                </p>
              </div>
              <div className="story-block">
                <h3>Rigorous Verification &amp; Personalized Pace</h3>
                <p>
                  Our simple goal is to connect students with verified, conceptually proficient tutors. We strictly
                  evaluate tutors for both subject knowledge and teaching proficiency. Rejecting "rushing the
                  syllabus," Tutoria creates personalized, conceptual learning plans tailored to each student's
                  adaptable learning pace — delivered seamlessly at home or online.
                </p>
              </div>
              <div className="story-block">
                <h3>Reinforcing Conceptual Confidence Across Metros</h3>
                <p>
                  Today, Tutoria supports families in large metros, with specialized focus on West Bengal (Kolkata,
                  Siliguri). Understanding the demands of school boards, our conceptual tutoring reinforces school
                  material, building clear understanding and academic confidence. Tutoria is your trusted partner in
                  learning.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* BOARDS / GRADES */}
      <section id="boards" className="boards-cinema">
        <div className="boards-frame">
          <div className="boards-header">
            <p className="boards-eyebrow">From ABCD to Board Exams</p>
            <h2 className="boards-title">Every grade, every board</h2>
            <p className="boards-sub">
              Wherever your child is in their studies, there is a tutor who has already taught that exact syllabus.
            </p>
          </div>

          <div className="boards-grid">
            {BOARDS_DATA.map((card, idx) => (
              <div key={idx} className={`board-card ${card.colorClass}`}>
                <div className="board-card-body">
                  <p className="board-tag">{card.tag}</p>
                  <h3 className="board-heading">{card.title}</h3>
                  <div className="board-divider"></div>
                  <p className="board-desc">{card.desc}</p>
                </div>
                <div className="board-icon-anchor">
                  {idx === 0 && (
                    <svg
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="#fff"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      aria-hidden="true"
                    >
                      <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" />
                      <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z" />
                      <path d="M8 7h6" />
                      <path d="M8 11h8" />
                    </svg>
                  )}
                  {idx === 1 && (
                    <svg
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="#fff"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      aria-hidden="true"
                    >
                      <path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z" />
                    </svg>
                  )}
                  {idx === 2 && (
                    <svg
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="#fff"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      aria-hidden="true"
                    >
                      <circle cx="12" cy="12" r="10" />
                      <circle cx="12" cy="12" r="6" />
                      <circle cx="12" cy="12" r="2" />
                    </svg>
                  )}
                  {idx === 3 && (
                    <svg
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="#fff"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      aria-hidden="true"
                    >
                      <path d="M4 15l7-7 4 4 5-5" />
                      <path d="M4 22h16" />
                      <path d="M20 7v6" />
                    </svg>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section id="how-it-works" className="how-cinema">
        <div className="how-frame">
          <div className="how-header">
            <p className="how-eyebrow">How It Works</p>
            <h2 className="how-title">Four steps to your first class</h2>
          </div>

          <div className="how-grid">
            {HOW_IT_WORKS_STEPS.map((step, idx) => (
              <div key={idx} className={`how-card ${step.colorClass}`}>
                <div className="how-card-body">
                  <p className="how-tag">{step.step}</p>
                  <h3 className="how-heading">{step.title}</h3>
                  <div className="how-divider"></div>
                  <p className="how-desc">{step.desc}</p>
                </div>
                <div className="how-icon-anchor">
                  {idx === 0 && (
                    <svg
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="#fff"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      aria-hidden="true"
                    >
                      <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" />
                    </svg>
                  )}
                  {idx === 1 && (
                    <svg
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="#fff"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      aria-hidden="true"
                    >
                      <circle cx="11" cy="11" r="8" />
                      <line x1="21" y1="21" x2="16.65" y2="16.65" />
                    </svg>
                  )}
                  {idx === 2 && (
                    <svg
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="#fff"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      aria-hidden="true"
                    >
                      <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
                      <line x1="16" y1="2" x2="16" y2="6" />
                      <line x1="8" y1="2" x2="8" y2="6" />
                      <line x1="3" y1="10" x2="21" y2="10" />
                    </svg>
                  )}
                  {idx === 3 && (
                    <svg
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="#fff"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      aria-hidden="true"
                    >
                      <path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z" />
                      <path d="M12 15l-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-3.05 11a22.35 22.35 0 0 1-3.95 2z" />
                    </svg>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* WHY TUTORIA */}
      <section id="why-tutoria" className="why-cinema">
        <div className="why-frame">
          <div className="why-header">
            <p className="why-eyebrow">Why Tutoria</p>
            <h2 className="why-title">What makes us different</h2>
          </div>

          <div className="why-grid">
            {WHY_TUTORIA_FEATURES.map((feat, idx) => (
              <div key={idx} className={`why-card ${feat.colorClass}`}>
                <div className="why-card-body">
                  <p className="why-tag">{feat.tag}</p>
                  <h3 className="why-heading">{feat.title}</h3>
                  <div className="why-divider"></div>
                  <p className="why-desc">{feat.desc}</p>
                </div>
                <div className="why-icon-anchor">
                  {idx === 0 && (
                    <svg
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="#fff"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      aria-hidden="true"
                    >
                      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
                      <path d="M9 12l2 2 4-4" />
                    </svg>
                  )}
                  {idx === 1 && (
                    <svg
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="#fff"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      aria-hidden="true"
                    >
                      <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
                      <circle cx="9" cy="7" r="4" />
                      <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
                      <path d="M16 3.13a4 4 0 0 1 0 7.75" />
                    </svg>
                  )}
                  {idx === 2 && (
                    <svg
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="#fff"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      aria-hidden="true"
                    >
                      <polygon points="5 3 19 12 5 21 5 3" />
                    </svg>
                  )}
                  {idx === 3 && (
                    <svg
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="#fff"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      aria-hidden="true"
                    >
                      <polyline points="23 4 23 10 17 10" />
                      <path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10" />
                    </svg>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* AREAS WE SERVE */}
      <section id="areas" className="areas-cinema">
        <div className="areas-frame">
          <div className="areas-header">
            <p className="areas-eyebrow">Areas We Serve</p>
            <h2 className="areas-title">Across West Bengal</h2>
          </div>
          <div className="areas-pills">
            {AREAS_LIST.map((area, idx) => (
              <div key={idx} className="area-pill">
                <svg className="area-pin" viewBox="0 0 24 24" aria-hidden="true">
                  <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" />
                </svg>
                <span>{area}</span>
              </div>
            ))}
            <button
              type="button"
              className="area-pill area-pill--cta cursor-pointer"
              onClick={onOpenAreaRequest}
              aria-label="Request a tutor for your specific area"
            >
              <svg className="area-plus" viewBox="0 0 24 24" aria-hidden="true">
                <path d="M12 5v14m-7-7h14" fill="none" stroke="#4ADE80" strokeWidth="2.5" strokeLinecap="round" />
              </svg>
              <span>More on request</span>
            </button>
          </div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section id="testimonials" className="testimonials-cinema">
        <div className="testimonials-frame">
          <div className="testimonials-header">
            <p className="testimonials-eyebrow">Testimonials</p>
            <h2 className="testimonials-title">What our community is saying</h2>
          </div>
          <div className="testi-track" id="testiTrack">
            {testimonials.length === 0 ? (
              <p className="testi-empty">No testimonials yet.</p>
            ) : (
              testimonials.map((t, i) => (
                <div key={t.id || i} className="testi-card">
                  <div className="testi-card-top">
                    <svg className="testi-quote-icon" viewBox="0 0 40 40" aria-hidden="true">
                      <circle cx="20" cy="20" r="20" fill="#FBF4E6" />
                      <path
                        d="M14 24h3.5l2-4V14h-5.5v6H16l-2 4zm7 0h3.5l2-4V14h-5.5v6H23l-2 4z"
                        fill="#F2994A"
                      />
                    </svg>
                    {renderStars(t.rating)}
                  </div>
                  <p className="testi-quote">{t.quote}</p>
                  <div className="testi-foot">
                    <div className={`testi-avatar testi-avatar--${(i % 3) + 1}`}>
                      {getInitials(t.name)}
                    </div>
                    <div>
                      <div className="testi-name">{t.name}</div>
                      <div className="testi-meta">{t.meta}</div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="faq-cinema">
        <div className="faq-frame">
          <div className="faq-header">
            <p className="faq-eyebrow">FAQs</p>
            <h2 className="faq-title">Common questions</h2>
          </div>
          <div className="faq">
            {HOME_FAQS.map((faq, idx) => {
              const isOpen = openFaqIndex === idx;
              return (
                <div key={idx} className={`faq-item ${isOpen ? 'open' : ''}`}>
                  <button
                    type="button"
                    className="faq-q"
                    onClick={() => toggleFaq(idx)}
                    aria-expanded={isOpen}
                  >
                    <span>{faq.q}</span>
                    <span className="plus" aria-hidden="true"></span>
                  </button>
                  <div className="faq-a">
                    <p>{faq.a}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>
    </div>
  );
};

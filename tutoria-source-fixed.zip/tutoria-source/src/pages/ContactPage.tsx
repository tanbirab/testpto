import React, { useState } from 'react';
import { TUTORIA_CONFIG } from '../data';

interface ContactPageProps {
  buildWhatsAppUrl: (message?: string) => string;
}

export const ContactPage: React.FC<ContactPageProps> = ({ buildWhatsAppUrl }) => {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    subject: '',
    message: '',
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const msg = `New enquiry — Tutoria
Name: ${formData.name}
Phone: ${formData.phone}
I'm a: ${formData.subject || 'Visitor'}
Message: ${formData.message || '-'}`;

    const url = buildWhatsAppUrl(msg);
    window.open(url, '_blank');
  };

  const scrollToForm = (e: React.MouseEvent) => {
    e.preventDefault();
    const target = document.getElementById('contact-form');
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="page-contact">
      {/* HERO */}
      <section className="hero hero-contact hero-full">
        <div className="hero-contact-frame">
          <div className="hero-contact-top">
            <p className="hero-contact-eyebrow">Reach Us</p>
            <h1 className="hero-contact-lead">
              Let's talk. <strong>We're just a message away.</strong>
            </h1>
          </div>

          <div className="hero-contact-card">
            <p className="hero-contact-card-eyebrow">Direct Contacts</p>
            <h2 className="hero-contact-card-title">Contact Details</h2>

            <div className="hero-contact-items">
              <div className="hero-contact-item">
                <span className="hero-contact-icon" aria-hidden="true">
                  <svg viewBox="0 0 44 44" width="44" height="44">
                    <circle cx="22" cy="22" r="22" fill="#228C68" fillOpacity="0.12" />
                    <path d="M22 12a10 10 0 0 0-8.5 15.3L12 31l3.9-1A10 10 0 1 0 22 12z" fill="#228C68" />
                  </svg>
                </span>
                <div>
                  <p className="hero-contact-label">
                    WhatsApp: <span>{TUTORIA_CONFIG.phoneDisplay}</span>
                  </p>
                  <p className="hero-contact-sub">Fastest response rate for all class &amp; subject inquiries</p>
                </div>
              </div>

              <div className="hero-contact-item">
                <span className="hero-contact-icon" aria-hidden="true">
                  <svg viewBox="0 0 44 44" width="44" height="44">
                    <circle cx="22" cy="22" r="22" fill="#0E3D2D" fillOpacity="0.08" />
                    <path d="M13 16h18v12H13z" fill="none" stroke="#0E3D2D" strokeWidth="2" strokeLinejoin="round" />
                    <path d="M13 16l9 6.5 9-6.5" fill="none" stroke="#0E3D2D" strokeWidth="2" strokeLinecap="round" />
                  </svg>
                </span>
                <p className="hero-contact-label">
                  Email: <span>{TUTORIA_CONFIG.email}</span>
                </p>
              </div>

              <div className="hero-contact-item">
                <span className="hero-contact-icon" aria-hidden="true">
                  <svg viewBox="0 0 44 44" width="44" height="44">
                    <circle cx="22" cy="22" r="22" fill="#0E3D2D" fillOpacity="0.08" />
                    <path
                      d="M22 11a6.5 6.5 0 0 0-6.5 6.5c0 4.8 6.5 11.5 6.5 11.5s6.5-6.7 6.5-11.5A6.5 6.5 0 0 0 22 11zm0 8.8a2.3 2.3 0 1 1 0-4.6 2.3 2.3 0 0 1 0 4.6z"
                      fill="#0E3D2D"
                    />
                  </svg>
                </span>
                <p className="hero-contact-label">
                  Service Area: <span>{TUTORIA_CONFIG.serviceArea}</span>
                </p>
              </div>

              <div className="hero-contact-item">
                <span className="hero-contact-icon" aria-hidden="true">
                  <svg viewBox="0 0 44 44" width="44" height="44">
                    <circle cx="22" cy="22" r="22" fill="#0E3D2D" fillOpacity="0.08" />
                    <circle cx="22" cy="22" r="9" fill="none" stroke="#0E3D2D" strokeWidth="2" />
                    <path d="M22 17v5h4" stroke="#0E3D2D" strokeWidth="2" strokeLinecap="round" />
                  </svg>
                </span>
                <p className="hero-contact-label">
                  Hours: <span>{TUTORIA_CONFIG.hours}</span>
                </p>
              </div>
            </div>
          </div>

          <div className="hero-contact-prompt">
            <p>We prefer WhatsApp, so a WhatsApp form is given below</p>
            <a
              href="#contact-form"
              onClick={scrollToForm}
              className="hero-contact-arrow"
              aria-label="Scroll to the contact form"
            >
              <svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true">
                <polyline
                  points="5,10 12,17 19,10"
                  fill="none"
                  stroke="#FFFFFF"
                  strokeWidth="2.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </a>
          </div>
        </div>
      </section>

      {/* CONTACT FORM */}
      <section className="contact-form-cinema" id="contact-form">
        <div className="contact-form-frame">
          <form className="wa-form-card" id="contactForm" onSubmit={handleSubmit}>
            <div className="wa-form-row">
              <div className="wa-field">
                <label htmlFor="contactName">Full name</label>
                <input
                  id="contactName"
                  type="text"
                  name="name"
                  placeholder="e.g. Rahul Sharma"
                  value={formData.name}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="wa-field">
                <label htmlFor="contactPhone">Phone number</label>
                <input
                  id="contactPhone"
                  type="tel"
                  name="phone"
                  placeholder="e.g. +91 98765 43210"
                  value={formData.phone}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="wa-field">
                <label htmlFor="contactSubject">I'm a...</label>
                <select
                  id="contactSubject"
                  name="subject"
                  value={formData.subject}
                  onChange={handleChange}
                  required
                >
                  <option value="" disabled>
                    Select one
                  </option>
                  <option value="Tutor">Tutor</option>
                  <option value="Parent">Parent</option>
                  <option value="Student">Student</option>
                </select>
              </div>
            </div>
            <div className="wa-field wa-field-message">
              <label htmlFor="contactMsg">Message</label>
              <textarea
                id="contactMsg"
                name="message"
                placeholder="Tell us a bit about what you're looking for..."
                value={formData.message}
                onChange={handleChange}
              ></textarea>
            </div>
            <button type="submit" className="wa-submit-btn" id="contactWhatsAppSubmit">
              <svg viewBox="0 0 32 32" aria-hidden="true">
                <path
                  fill="currentColor"
                  d="M16.001 3C9.096 3 3.5 8.596 3.5 15.5c0 2.42.67 4.68 1.83 6.61L3 29l7.06-2.28a12.44 12.44 0 0 0 5.94 1.52h.01c6.9 0 12.5-5.6 12.5-12.5S22.9 3 16 3Zm0 22.6h-.01a10.4 10.4 0 0 1-5.31-1.46l-.38-.22-4.19 1.35 1.37-4.08-.25-.42a10.36 10.36 0 0 1-1.6-5.5c0-5.75 4.68-10.43 10.44-10.43 2.79 0 5.41 1.09 7.38 3.06a10.35 10.35 0 0 1 3.05 7.37c0 5.75-4.69 10.43-10.5 10.43Zm5.72-7.8c-.31-.16-1.85-.91-2.14-1.02-.29-.1-.5-.16-.71.16-.21.31-.81 1.02-1 1.23-.18.21-.37.23-.68.08-.31-.16-1.32-.49-2.51-1.55-.93-.83-1.56-1.86-1.74-2.17-.18-.31-.02-.48.14-.63.14-.14.31-.37.47-.55.16-.19.21-.31.31-.52.1-.21.05-.39-.03-.55-.08-.16-.71-1.71-.97-2.34-.26-.62-.52-.53-.71-.54h-.6c-.21 0-.55.08-.84.39-.29.31-1.1 1.08-1.1 2.62 0 1.55 1.13 3.05 1.29 3.26.16.21 2.22 3.39 5.38 4.75.75.32 1.34.51 1.8.66.76.24 1.44.21 1.99.13.61-.09 1.85-.76 2.11-1.49.26-.73.26-1.36.18-1.49-.08-.13-.29-.21-.6-.37Z"
                />
              </svg>
              <span>Send via WhatsApp</span>
            </button>
            <p className="wa-form-note">This opens WhatsApp with your message pre-filled — just hit send.</p>
          </form>
        </div>
      </section>
    </div>
  );
};

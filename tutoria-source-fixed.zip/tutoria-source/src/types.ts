export interface Testimonial {
  id?: string;
  name: string;
  meta: string;
  quote: string;
  rating?: string;
}

export interface PendingReview {
  id?: string;
  name: string;
  meta: string;
  quote: string;
  rating?: string;
  submittedAt?: string;
}

export interface AreaRequest {
  id: string;
  name?: string;
  phone: string;
  area: string;
  classOrExam: string;
  tutoringType: string;
  notes?: string;
  submittedAt: string;
  status?: 'Pending' | 'Contacted' | 'Assigned';
}

export interface TutorApplication {
  id: string;
  name: string;
  phone: string;
  qualification: string;
  experience: string;
  subjects: string;
  grades: string;
  area: string;
  notes?: string;
  submittedAt: string;
  status?: 'Pending' | 'Verified' | 'Contacted' | 'Rejected';
}

export type PageId = 'home' | 'join-as-tutor' | 'apply' | 'contact' | 'review';

export interface BoardLevel {
  tag: string;
  title: string;
  desc: string;
  icon: string;
  colorClass: string;
}

export interface StepItem {
  step: string;
  title: string;
  desc: string;
  icon: string;
  colorClass: string;
}

export interface WhyFeature {
  tag: string;
  title: string;
  desc: string;
  icon: string;
  colorClass: string;
}

export interface FaqItem {
  q: string;
  a: string;
}
